import signal
import sys
import env_desarrollo_config as Entorno
import common_logging as log
import common_profiler as prof
import common_spark as sp
from pyspark.sql import *

log.rootLogger = log.configLogging(Entorno.LOG_PATH, Entorno.LOG_FILE_NAME_CREATE_HIVE_DATA, Entorno.LOG_LEVEL_INFO)
_spark = None

def signal_handler(sig, frame):
    """ Atrapa el Control+C """
    sp.closeSparkSession(_spark)
    log.rootLogger.info('Graceful shutdown completed')
    sys.exit(0)

signal.signal(signal.SIGINT, signal_handler)

@prof.profileInSeconds
def create_hive_data():
    log.rootLogger.info('Inicia el proceso: create-hive-data')
    log.rootLogger.info('Solicitando Spark Context')
    _spark, _sparkContext = sp.createHiveContext('create-hive-data', Entorno.SPARK_DRIVER_CORES_4, Entorno.SPARK_CORES_MAX_8, Entorno.SPARK_EXECUTOR_CORES_4, Entorno.SPARK_EXECUTOR_MEMORY_1)

    nombreCubo = 'fiscar.test_integracion_01'

    # Create the Departments
    department1 = Row(id='123456', name='Computer Science')
    department2 = Row(id='789012', name='Mechanical Engineering')
    # Create the Employees
    Employee = Row("firstName", "lastName", "email", "salary")
    employee1 = Employee('michael', 'armbrust', 'no-reply@berkeley.edu', 100000)
    employee2 = Employee('xiangrui', 'meng', 'no-reply@stanford.edu', 120000)
    employee3 = Employee('matei', None, 'no-reply@waterloo.edu', 140000)
    employee4 = Employee(None, 'wendell', 'no-reply@berkeley.edu', 160000)
    # Create the DepartmentWithEmployees instances from Departments and Employees
    departmentWithEmployees1 = Row(department=department1, employees=[employee1, employee2])
    departmentWithEmployees2 = Row(department=department2, employees=[employee3, employee4])
    departmentsWithEmployeesSeq1 = [departmentWithEmployees1, departmentWithEmployees2]

    log.rootLogger.info('Obteniendo el dataset en base la lista de columnas')
    ds_spark = sp.create_data_frame(_spark, departmentsWithEmployeesSeq1)

    log.rootLogger.info('Guardando el dataset en el cubo: ' + nombreCubo)
    sp.saveDataSetToHDFS(dataset = ds_spark,
        format = 'parquet',
        mode = 'overwrite',
        tableName = nombreCubo)

    log.rootLogger.info('Cerrando Spark')
    sp.closeSparkSession(_spark)

    log.rootLogger.info('Fin del proceso: x-ingest-01')

create_hive_data()