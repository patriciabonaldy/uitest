import sys
sys.path.append('.')
import time
import os
import env_desarrollo_config as Entorno
from selenium import webdriver
# from pyvirtualdisplay import Display
from selenium.webdriver import Firefox
from selenium.webdriver.firefox.options import Options as FirefoxOptions
from selenium.webdriver import Chrome
from selenium.webdriver.chrome.options import Options as ChromeOptions
from selenium.common.exceptions import TimeoutException
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By
from selenium.webdriver.common.actions import action_builder
from selenium.webdriver.common.action_chains import ActionChains


def set_up_browser(selected_browser, _headless):
    browser = ''

    if selected_browser == 'Firefox':
        opts = FirefoxOptions()
        opts.set_headless(headless=_headless)
        firefox_profile = webdriver.FirefoxProfile()
        firefox_profile.set_preference("browser.privatebrowsing.autostart", False)
        #firefox_profile.set_preference("marionette", True) # remove if causing issues

        browser = webdriver.Firefox(executable_path="./geckodriver", firefox_profile=firefox_profile, firefox_options=opts)
    elif selected_browser == 'Chrome':
        opts = ChromeOptions()
        opts.set_headless(headless=_headless)
        opts.add_argument("--no-sandbox")
        opts.add_argument("--incognito")
        opts.add_argument("--start-maximized")
        browser = webdriver.Chrome(executable_path="./chromedriver", chrome_options=opts)
    elif selected_browser == 'edge':
         pass
    else:
        print('unsupported browser')
        exit
    #browser.set_window_size(1200, 900)
    browser.delete_all_cookies()
    browser.refresh()
    return browser

def drag_and_drop_html5_style(browser, source, target):
    try:
        # Local JQuery
        script = ''
        with open(os.path.abspath('jquery-1.11.3.min.js'), 'r') as js_file:
            line = js_file.readline()
            while line:
                script += line 
                line = js_file.readline()
        # Local helper
        with open(os.path.abspath('drag_and_drop_helper.js'), 'r') as js_file:
            line = js_file.readline()
            while line:
                script += line 
                line = js_file.readline()

        complete_script = script + "$('" + source + "').simulateDragDrop({ dropTarget: '" + target + "'});"
        browser.execute_script(complete_script)
    except Exception as e:
        print(e)

def buscar_xpath(browser, elemento):
    try:
        browser.find_element_by_xpath(elemento).click()
    except TimeoutException:
        print("Error clickeando el XPATH: " + elemento)

screenshot_seq = 1

def screenshot(browser, name):
    browser.implicitly_wait(1)
    global screenshot_seq
    screenshot_filename = './images/' + format(screenshot_seq, '02') + '_' + name  + '.png'
    print('  [IMG]  [name:  ' + screenshot_filename + ']')
    screenshot_seq = screenshot_seq + 1
    browser.save_screenshot(screenshot_filename)

def esperar_presencia_xpath(browser, timeout, elemento):
    try:
        element_present = EC.presence_of_element_located((By.XPATH, '//*[@id="app"]/div/main/div/div[1]/div/nav/div/div[2]'))
        WebDriverWait(browser, timeout).until(element_present)
    except TimeoutException:
        print("Timed out esperando que cargue la pagina")

def esperar_visibilidad_xpath(browser, timeout, elemento):
    try:
        element_present = EC.visibility_of_element_located((By.XPATH, elemento))
        WebDriverWait(browser, timeout).until(element_present)
    except TimeoutException:
        print("Timed out esperando que el elemento sea visible")

def esperar_visibilidad_css_sel(browser, timeout, elemento):
    try:
        element_present = EC.visibility_of_element_located((By.CSS_SELECTOR, elemento))
        WebDriverWait(browser, timeout).until(element_present)
    except TimeoutException:
        print("Timed out esperando que el elemento sea visible")

def esperar_clickeabilidad_xpath(browser, timeout, elemento):
    try:
        element_present = EC.element_to_be_clickable((By.XPATH, elemento))
        WebDriverWait(browser, timeout).until(element_present)
    except TimeoutException:
        print("Timed out esperando que el elemento sea clickeable")

def esperar_clickeabilidad_css_sel(browser, timeout, elemento):
    try:
        element_present = EC.element_to_be_clickable((By.CSS_SELECTOR, elemento))
        WebDriverWait(browser, timeout).until(element_present)
    except TimeoutException:
        print("Timed out esperando que el elemento sea clickeable")

def buscar_clickear_xpath(browser, elemento):
    try:
        e = browser.find_element_by_xpath(elemento)
        e.click()
    except TimeoutException:
        print("Error buscando y clickeando")
    return e