# UI Tests
#
# Author: Jose Figueredo
#
#
import sys
sys.path.append('.')
import time
import os
import signal
import env_desarrollo_config as Entorno
import common_selenium as cs
import common_logging as log
import common_profiler as prof
import common_spark as sp


log.rootLogger = log.configLogging(Entorno.LOG_PATH, Entorno.LOG_FILE_NAME_TEST_M1, Entorno.LOG_LEVEL_INFO)
_spark = None

def signal_handler(sig, frame):
    """ Atrapa el Control+C """
    sp.closeSparkSession(_spark)
    log.rootLogger.info('Graceful shutdown completed')
    sys.exit(0)

signal.signal(signal.SIGINT, signal_handler)


#selected_browser = 'Chrome'
selected_browser = 'Firefox'
headless = False
URL_HOME = 'http://localhost:8080/webapp/#/'

def test_fiscar():
    # Abro Browser
    browser = cs.set_up_browser(selected_browser, headless)
    timeout = 10

    # Abro Home
    browser.get(URL_HOME)

    # --------------------------------------------------------------------------------
    # Logueo
    print('Logueo:')
    cs.esperar_presencia_xpath(browser, timeout, '//*[@id="app"]/div/main/div/div[1]/div/nav/div/div[2]')
    print('  [HTML] [title: ' + browser.title + ']')
    print('  [HTML] [url:   ' + browser.current_url + ']')
    cs.screenshot(browser, 'home')

    # --------------------------------------------------------------------------------
    # Entro a tab Explorar
    explorar_div = browser.find_element_by_xpath('//*[@id="app"]/div/main/div/div[1]/div/nav/div/div[4]/a[1]/div')
    explorar_div.click()

    cs.esperar_presencia_xpath(browser, timeout, '//*[@id="app"]/div[2]/div/div/div[1]/span')
    print('  [HTML] [title: ' + browser.title + ']')
    print('  [HTML] [url:   ' + browser.current_url + ']')

    cs.screenshot(browser, 'explorar')

    cs.esperar_presencia_xpath(browser, timeout, '//*[@id="app"]/div[2]/div/div/div[2]/div/div/div[1]/div/div/div[1]/div/div[1]')
    el = cs.buscar_clickear_xpath(browser, '//*[@id="app"]/div[2]/div/div/div[2]/div/div/div[1]/div/div/div[1]/div/div[1]')
    browser.implicitly_wait(1)
    el.click()
    browser.implicitly_wait(1)

    cs.buscar_clickear_xpath(browser, '/html/body/div/div[4]/div/div/div[2]/div/div/div[2]/div/div/div/div[2]/div[1]/div/input')

    cs.esperar_clickeabilidad_xpath(browser, timeout, '/html/body/div/div[2]/div/div/div/div[1]/button[1]')
    el = cs.buscar_clickear_xpath(browser, '/html/body/div/div[2]/div/div/div/div[1]/button[1]')
    browser.implicitly_wait(1)
    el.click()
    browser.implicitly_wait(1)
    el.click()

    cs.esperar_visibilidad_xpath(browser, timeout, '/html/body/div/div[2]/div/div/div/div[2]/table/tbody/tr[1]/td[2]/button')

    calendar_febrero_btn = browser.find_element_by_xpath('/html/body/div/div[2]/div/div/div/div[2]/table/tbody/tr[1]/td[2]/button')
    calendar_febrero_btn.click()

    calendar_hasta_inp = browser.find_element_by_xpath('/html/body/div/div[4]/div/div/div[2]/div/div/div[3]/div/div/div/div[2]/div[1]/div/input')
    calendar_hasta_inp.click()

    cs.esperar_visibilidad_xpath(browser, timeout, '/html/body/div/div[1]/div/div/div/div[2]/table/tbody/tr[1]/td[1]/button')
    calendar_enero_btn = browser.find_element_by_xpath('/html/body/div/div[1]/div/div/div/div[2]/table/tbody/tr[1]/td[1]/button')
    calendar_enero_btn.click()
    cs.screenshot(browser, 'explorar')

    cs.buscar_clickear_xpath(browser, '/html/body/div/div[4]/div/div/div[3]/button[1]')
    browser.implicitly_wait(1)
    cs.screenshot(browser, 'explorar')

    # --------------------------------------------------------------------------------
    # Presiono boton del menu lateral: Contribuyentes
    cs.buscar_clickear_xpath(browser, '/html/body/div/div[12]/main/div/div[2]/div/aside/div[1]/div/div[2]/div[1]/div/a')

    cs.esperar_clickeabilidad_xpath(browser, timeout, '/html/body/div/div[12]/main/div/div[2]/div/aside/div[2]/div/div[2]/div[1]/div[1]/div/div[2]/div')
    cs.buscar_clickear_xpath(browser, '/html/body/div/div[12]/main/div/div[2]/div/aside/div[2]/div/div[2]/div[1]/div[1]/div/div[2]/div')

    # --------------------------------------------------------------------------------
    # Drag & Drop Cuit a Columnas
    # Seccion barra lateral, Elemento CUIT
    cs.esperar_visibilidad_css_sel(browser, timeout, 'div.drag:nth-child(1)')
    # Seccion Columnas
    cs.esperar_visibilidad_css_sel(browser, timeout, '.containerFiltro > div:nth-child(2) > div:nth-child(1) > div:nth-child(1) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1)')
    cs.drag_and_drop_html5_style(browser, 'div.drag:nth-child(1)', '.containerFiltro > div:nth-child(2) > div:nth-child(1) > div:nth-child(1) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1)')
    cs.screenshot(browser, 'explorar')
    browser.implicitly_wait(1)


    # --------------------------------------------------------------------------------
    # Presiono boton Calcular
    cs.buscar_clickear_xpath(browser, '//*[@id="app"]/div[12]/main/div/div[2]/div/div[1]/div[3]/button')
    cs.screenshot(browser, 'calcular')
    browser.implicitly_wait(1)

    # --------------------------------------------------------------------------------
    # Espero y Presiono boton Ejecutar
    cs.esperar_clickeabilidad_css_sel(browser, timeout, 'button.primary:nth-child(2)')
    cs.buscar_clickear_xpath(browser, '//*[@id="app"]/div[2]/div/div/div[3]/button[1]')

    #Flecha
    #/html/body/div/div[13]/main/div/div[2]/div/div[1]/div[4]/div/div/div[2]/div/div[2]/button[2]

    # Cierro Firefox
    #browser.close()

test_fiscar()
