import logging
import coloredlogs
import env_desarrollo_config as Entorno

FIELD_STYLES = dict(
    asctime=dict(color='green'),
    hostname=dict(color='magenta'),
    levelname=dict(color='green', bold=coloredlogs.CAN_USE_BOLD_FONT),
    filename=dict(color='magenta'),
    programname=dict(color='cyan'),
    name=dict(color='blue'),
    threadName=dict(color='cyan')
)

LEVEL_STYLES = dict(
    spam=dict(color='green', faint=True),
    debug=dict(color='green'),
    verbose=dict(color='blue'),
    info=dict(color='white'),
    notice=dict(color='magenta'),
    warning=dict(color='yellow'),
    success=dict(color='green', bold=coloredlogs.CAN_USE_BOLD_FONT),
    error=dict(color='red'),
    critical=dict(color='red', bold=coloredlogs.CAN_USE_BOLD_FONT)
)

def configLogging(path, fileName, logLevel):
    formatter = "%(asctime)s [%(threadName)-12.12s] [%(levelname)-5.5s]  %(message)s"
    logFormatter = logging.Formatter(formatter)
    filePathAndName = "{0}/{1}.log".format(path, fileName)
    fileHandler = logging.FileHandler(filePathAndName)
    fileHandler.setFormatter(logFormatter)
    rootLogger.addHandler(fileHandler)
    consoleHandler = logging.StreamHandler()
    consoleHandler.setFormatter(logFormatter)
    rootLogger.addHandler(consoleHandler)
    rootLogger.setLevel(logLevel)
    rootLogger.info('Logging configurado: ' + filePathAndName)
    coloredlogs.install(
        level=logLevel,
        logger=rootLogger,
        fmt=formatter,
        milliseconds=True,
        level_styles=LEVEL_STYLES,
        field_styles=FIELD_STYLES
    )
    return rootLogger

rootLogger = logging.getLogger()
