import time
import decimal
import common_logging as log
import common_shell_colors as col

ctx = decimal.Context()
ctx.prec = 10

def float_to_str(f):
    """ Convierte un float a string sin usar notacion cientifica """
    d1 = ctx.create_decimal(repr(f))
    return format(d1, 'f')

def profile(func):
    """ Decorator que calcula el tiempo que tarda una funcion.
        Uso: @profile antes de def """
    def wrap(*args, **kwargs):
        started_at = time.time()
        result = func(*args, **kwargs)
        elapsedMs = (time.time() - started_at) * 1000
        log.rootLogger.info('f: ' + func.__name__ + ' has taken: ' + float_to_str(elapsedMs) + ' ms')
        #log.rootLogger.info(col.highlight('yellow', col.colourise('black', 'f: ' + func.__name__ + ' has taken: ' + float_to_str(elapsedMs) + ' ms')))
        return result
    return wrap

def profileInSeconds(func):
    """ Decorator que calcula el tiempo que tarda una funcion.
        Uso: @profile antes de def """
    def wrap(*args, **kwargs):
        started_at = time.time()
        result = func(*args, **kwargs)
        elapsedMs = (time.time() - started_at)
        log.rootLogger.info('f: ' + func.__name__ + ' has taken: ' + float_to_str(elapsedMs) + ' s')
        #log.rootLogger.info(col.highlight('yellow', col.colourise('black', 'f: ' + func.__name__ + ' has taken: ' + float_to_str(elapsedMs) + ' s')))
        return result
    return wrap