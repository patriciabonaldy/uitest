from pyspark import SparkConf, SparkContext
from pyspark.sql import HiveContext
from pyspark.sql import SparkSession
import env_desarrollo_config as Entorno
import signal
import sys
import io
import os
import common_logging as log
import common_profiler as prof

@prof.profileInSeconds
def createHiveContext(jobName, driverCores, coresMax, executorCores, executorMemory):
    """ Instancia un hive context """
    try:
        SUBMIT_ARGS = "--jars ./ojdbc8.jar pyspark-shell"
        os.environ["PYSPARK_SUBMIT_ARGS"] = SUBMIT_ARGS
        conf = SparkConf()
        conf.setMaster(Entorno.SPARK_MASTER_URL)
        jobName = jobName
        log.rootLogger.info('Ejecutando: ' + jobName)
        conf.setAppName(jobName)
        conf.set('spark.driver.cores', str(driverCores))
        conf.set('spark.cores.max', str(coresMax))
        conf.set('spark.executor.cores', str(executorCores))
        conf.set('spark.executor.memory', executorMemory)
        conf.set('spark.ui.enabled', 'false')
        conf.set('spark.eventLog.enabled', 'true')
        #conf.set('spark.serializer', 'org.apache.spark.serializer.KryoSerializer')
        _spark = SparkSession.builder.config(conf=conf).enableHiveSupport().getOrCreate()
        sc = _spark.sparkContext
        sc.setLogLevel('WARN')
        _sqlContext = HiveContext(sc)
        try:
            log4jLogger = _spark._jvm.org.apache.log4j.Logger
            if log4jLogger != None:
                sparkLog = log4jLogger.LogManager.getLogger(__name__) 
                sparkLog.info('Ejecutando: ' + jobName)
        except Exception as e:
            pass
    except Exception as e:
        log.rootLogger.error('Exception: ' + str(e))
    return _spark, _sqlContext

@prof.profile
def closeSparkSession(_spark):
    if _spark != None:
        _spark.stop()
        log.rootLogger.info('Spark session has been shut down')

@prof.profileInSeconds
def getOracleDataSet(query, _spark, partition = False, numPartitions = None, partitionColumn = None, lowerBound = None, upperBound = None, fetchSize = 1000):
    ds_ora = None
    try:
        if partition != None and partition:
            ds_ora = _spark.read \
            .format("jdbc") \
            .option("url", "jdbc:oracle:thin:" + Entorno.MAIN_USER + "/" + Entorno.MAIN_PASSWORD + "@//" + Entorno.CONNECT_STRING) \
            .option("dbtable", query) \
            .option("user", Entorno.MAIN_USER) \
            .option("password", Entorno.MAIN_PASSWORD) \
            .option("driver", "oracle.jdbc.driver.OracleDriver") \
            .option("numPartitions", numPartitions) \
            .option("partitionColumn", partitionColumn) \
            .option("lowerBound", lowerBound) \
            .option("upperBound", upperBound) \
            .option("fetchSize", fetchSize) \
            .load()
        else:
            ds_ora = _spark.read \
            .format("jdbc") \
            .option("url", "jdbc:oracle:thin:" + Entorno.MAIN_USER + "/" + Entorno.MAIN_PASSWORD + "@//" + Entorno.CONNECT_STRING) \
            .option("dbtable", query) \
            .option("user", Entorno.MAIN_USER) \
            .option("password", Entorno.MAIN_PASSWORD) \
            .option("driver", "oracle.jdbc.driver.OracleDriver") \
            .option("fetchSize", fetchSize) \
            .load()
    except Exception as e:
        log.rootLogger.error('Exception: ' + str(e))
    return ds_ora

@prof.profileInSeconds
def saveDataSetToHDFS(dataset, format, mode, tableName):
    try:
        dataset.write.format(format) \
            .mode(mode) \
            .saveAsTable(tableName)
    except Exception as e:
        log.rootLogger.error('Exception: ' + str(e))

@prof.profileInSeconds
def saveDataSetToHDFSPartitioned(dataset, format, mode, tableName, columnName):
    try:
        dataset.write.format(format) \
            .mode(mode) \
            .partitionBy(columnName) \
            .saveAsTable(tableName)
    except Exception as e:
        log.rootLogger.error('Exception: ' + str(e))

@prof.profileInSeconds
def getDataSet(_sqlContext, query):
    ds = None
    try:
        ds = _sqlContext.sql(query)
    except Exception as e:
        log.rootLogger.error('Exception: ' + str(e))
    return ds

@prof.profileInSeconds
def create_data_frame(_spark, data):
    ds = None
    try:
        ds = _spark.createDataFrame(data)
    except Exception as e:
        log.rootLogger.error('Exception: ' + str(e))
    return ds
